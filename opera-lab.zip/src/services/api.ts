/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { StudentPerformanceData, ReposicaoItem, SafireStudentCheck } from '../types';
import { getProfEmail, EMAIL_VERIFICACAO, EMAIL_COORDENACAO } from '../data/database';

export const URL_API_DESEMPENHO = "https://script.google.com/macros/s/AKfycbxXEwBn5elEygEqZFt8bNlBZ6w98w5Xed2Z44zdTF93mRGKb--6ZGrZ3BEK80zUDRlRtg/exec";
export const SCRIPT_URL_SAFIRE = "https://script.google.com/macros/s/AKfycbz-6QfjR8G4V6jCgZztYNu7LcOGjXIQtYYZ06ZCzsMjs9LAaMdI5e4B2JpORm_zlnv_Pw/exec";

export function normalizeString(str?: string): string {
  if (!str) return "";
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

/**
 * Carrega a base de dados de avaliações com fallback para cache local
 */
export async function fetchDesempenhoData(): Promise<StudentPerformanceData> {
  const cached = localStorage.getItem('opera_dbNotasCloud');
  let data: StudentPerformanceData = {};
  if (cached) {
    try {
      data = JSON.parse(cached);
    } catch {
      // ignore
    }
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 9000);
    const res = await fetch(`${URL_API_DESEMPENHO}?action=read&_t=${Date.now()}`, {
      signal: controller.signal,
      cache: 'no-store'
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      const json = await res.json();
      if (json && typeof json === 'object') {
        data = json;
        localStorage.setItem('opera_dbNotasCloud', JSON.stringify(json));
      }
    }
  } catch {
    console.warn("Utilizando dados de desempenho armazenados localmente.");
  }

  return data;
}

/**
 * Salva notas do aluno no Google Apps Script e atualiza cache
 */
export async function saveStudentPerformance(
  aluno: string,
  turma: string,
  prof: string,
  notas: unknown
): Promise<boolean> {
  // Salva no cache local imediatamente (optimistic)
  try {
    const cached = localStorage.getItem('opera_dbNotasCloud');
    const localData = cached ? JSON.parse(cached) : {};
    localData[aluno] = notas;
    localStorage.setItem('opera_dbNotasCloud', JSON.stringify(localData));
  } catch {
    // ignore
  }

  const params = new URLSearchParams();
  params.append('action', 'save');
  params.append('aluno', aluno);
  params.append('turma', turma);
  params.append('prof', prof);
  params.append('notas', JSON.stringify(notas));

  try {
    await fetch(URL_API_DESEMPENHO, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });
    return true;
  } catch (error) {
    console.error("Erro ao salvar na nuvem:", error);
    return false;
  }
}

/**
 * Exclui registro de aluno
 */
export async function deleteStudentPerformance(aluno: string): Promise<boolean> {
  try {
    const cached = localStorage.getItem('opera_dbNotasCloud');
    if (cached) {
      const localData = JSON.parse(cached);
      delete localData[aluno];
      localStorage.setItem('opera_dbNotasCloud', JSON.stringify(localData));
    }
  } catch {
    // ignore
  }

  const params = new URLSearchParams();
  params.append('action', 'delete');
  params.append('aluno', aluno);

  try {
    await fetch(URL_API_DESEMPENHO, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });
    return true;
  } catch {
    return false;
  }
}

/**
 * Registra chamada / diário de classe
 */
export async function registrarChamadaNuvem(
  prof: string,
  turma: string,
  dataAula: string,
  licao: string,
  dadosChamada: { nome: string; status: string }[]
): Promise<boolean> {
  const params = new URLSearchParams();
  params.append('action', 'registrar_chamada');
  params.append('prof', prof);
  params.append('turma', turma);
  params.append('dataAula', dataAula);
  params.append('licao', licao);
  params.append('dadosChamada', JSON.stringify(dadosChamada));

  try {
    await fetch(URL_API_DESEMPENHO, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });
    return true;
  } catch {
    return false;
  }
}

/**
 * Lista reposições cadastradas
 */
export async function fetchReposicoes(): Promise<ReposicaoItem[]> {
  let cloudItems: ReposicaoItem[] = [];

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 9000);
    const res = await fetch(`${URL_API_DESEMPENHO}?action=listar_reposicoes&_t=${Date.now()}`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data)) {
        cloudItems = data.map((item: any, idx: number) => ({
          id: item.id ? String(item.id) : `rep_${idx}_${Date.now()}`,
          tipo: item.tipo || item.tipoAula || 'Reposição',
          aluno: item.aluno || item.nomeAluno || item.nome || '',
          turma: item.turma || item.codigoTurma || '',
          status: (item.status || item.situacao || 'Pendente') as any,
          profSub: item.profSub || item.profSubstituto || item.substituto || item.professor || item.prof || '',
          profOriginal: item.profOriginal || item.professorOriginal || item.prof || '',
          data: item.data || item.dataRep || item.dataBr || item.dataAula || '',
          hora: item.hora || item.horaRep || item.horario || item.horaAula || '',
          licao: item.licao || item.conteudo || item.licoes || '',
          modalidade: item.modalidade || 'Online',
          staff: item.staff || item.agendadoPor || item.solicitante || '',
          historico: item.historico || item.criadoEm || '',
          agendadoPor: item.agendadoPor || item.staff || ''
        }));
      }
    }
  } catch (error) {
    console.warn("Erro ao buscar reposições da nuvem:", error);
  }

  // Mescla com cache local para não perder agendamentos recém-criados
  try {
    const cached = localStorage.getItem('opera_reposicoes_cache');
    const localList: ReposicaoItem[] = cached ? JSON.parse(cached) : [];
    
    if (cloudItems.length > 0) {
      const merged = [...cloudItems];
      // Adiciona itens locais que ainda não apareceram na nuvem
      localList.forEach((loc) => {
        const jaExiste = merged.some(
          (m) =>
            m.id === loc.id ||
            (normalizeString(m.aluno) === normalizeString(loc.aluno) &&
              normalizeString(m.data) === normalizeString(loc.data) &&
              m.hora === loc.hora)
        );
        if (!jaExiste) {
          merged.unshift(loc);
        }
      });
      localStorage.setItem('opera_reposicoes_cache', JSON.stringify(merged));
      return merged;
    } else if (localList.length > 0) {
      return localList;
    }
  } catch {
    // ignore
  }

  return cloudItems;
}

/**
 * Atualiza status de presença ou cancelamento de reposição
 */
export async function updateReposicaoStatus(
  id: string,
  novoStatus: string,
  staffOuProf: string
): Promise<boolean> {
  // Atualiza cache local instantaneamente
  try {
    const cached = localStorage.getItem('opera_reposicoes_cache');
    if (cached) {
      const list: ReposicaoItem[] = JSON.parse(cached);
      const updated = list.map((item) =>
        item.id === id ? { ...item, status: novoStatus as any } : item
      );
      localStorage.setItem('opera_reposicoes_cache', JSON.stringify(updated));
    }
  } catch {
    // ignore
  }

  const params = new URLSearchParams();
  params.append('action', 'atualizar_reposicao');
  params.append('id', id);
  params.append('status', novoStatus);
  params.append('situacao', novoStatus);
  params.append('staff', staffOuProf);
  params.append('responsavel', staffOuProf);

  try {
    await fetch(URL_API_DESEMPENHO, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });
    return true;
  } catch {
    return false;
  }
}

/**
 * Agenda nova reposição / monitoria com envio completo de parâmetros,
 * salvamento otimista na agenda local e disparo de email/notificações
 */
export async function agendarReposicao(dados: {
  tipo: string;
  aluno: string;
  turma: string;
  profOriginal: string;
  profSub: string;
  licao: string;
  modalidade: string;
  dataRep: string;
  horaRep: string;
  staff: string;
}): Promise<boolean> {
  const partesData = dados.dataRep.includes('-') ? dados.dataRep.split('-') : [];
  const dataBr = partesData.length === 3 ? `${partesData[2]}/${partesData[1]}/${partesData[0]}` : dados.dataRep;
  const dataIso = dados.dataRep;

  // Calcula horário de término (+1 hora por padrão)
  let horaFim = dados.horaRep;
  if (dados.horaRep && dados.horaRep.includes(':')) {
    const [h, m] = dados.horaRep.split(':').map(Number);
    const endH = (h + 1) % 24;
    horaFim = `${String(endH).padStart(2, '0')}:${String(m || 0).padStart(2, '0')}`;
  }

  // Puxa e-mails reais do professor substituto e original do banco do projeto
  const emailProfSub = getProfEmail(dados.profSub);
  const emailProfOriginal = getProfEmail(dados.profOriginal);

  const novoId = `rep_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const novoItem: ReposicaoItem = {
    id: novoId,
    tipo: dados.tipo,
    aluno: dados.aluno,
    turma: dados.turma,
    profOriginal: dados.profOriginal,
    profSub: dados.profSub,
    licao: dados.licao,
    modalidade: dados.modalidade,
    data: dataBr,
    hora: dados.horaRep,
    status: 'Pendente',
    staff: dados.staff,
    agendadoPor: dados.staff,
    criadoEm: new Date().toLocaleDateString('pt-BR')
  };

  // 1. Atualiza cache local instantaneamente para a agenda abrir imediatamente com o evento
  try {
    const cached = localStorage.getItem('opera_reposicoes_cache');
    const list: ReposicaoItem[] = cached ? JSON.parse(cached) : [];
    list.unshift(novoItem);
    localStorage.setItem('opera_reposicoes_cache', JSON.stringify(list));
  } catch {
    // ignore
  }

  // 2. Monta parâmetros abrangentes para o Google Apps Script (Email + Google Calendar + Banco)
  const params = new URLSearchParams();
  params.append('action', 'agendar_reposicao');
  params.append('tipo', dados.tipo);
  params.append('tipoAula', dados.tipo);
  params.append('aluno', dados.aluno);
  params.append('nomeAluno', dados.aluno);
  params.append('nome', dados.aluno);
  params.append('turma', dados.turma);
  params.append('codigoTurma', dados.turma);
  params.append('profOriginal', dados.profOriginal);
  params.append('professorOriginal', dados.profOriginal);
  params.append('profSub', dados.profSub);
  params.append('professor', dados.profSub);
  params.append('prof', dados.profSub);
  params.append('profSubstituto', dados.profSub);
  params.append('substituto', dados.profSub);
  params.append('licao', dados.licao);
  params.append('conteudo', dados.licao);
  params.append('modalidade', dados.modalidade);
  params.append('dataRep', dataIso);
  params.append('data', dataBr);
  params.append('dataBr', dataBr);
  params.append('dataIso', dataIso);
  params.append('horaRep', dados.horaRep);
  params.append('hora', dados.horaRep);
  params.append('horaInicio', dados.horaRep);
  params.append('horaFim', horaFim);
  params.append('horario', dados.horaRep);
  params.append('staff', dados.staff);
  params.append('agendadoPor', dados.staff);
  
  // E-mails reais dos professores e cópia de verificação
  params.append('emailProfessor', emailProfSub);
  params.append('profEmail', emailProfSub);
  params.append('emailProfSub', emailProfSub);
  params.append('emailProfOriginal', emailProfOriginal);
  params.append('emailDestino', emailProfSub);
  params.append('emailVerificacao', EMAIL_VERIFICACAO);
  params.append('emailCopia', EMAIL_COORDENACAO);
  params.append('emailsNotificacao', `${emailProfSub},${EMAIL_VERIFICACAO},${EMAIL_COORDENACAO}`);

  // Gatilhos de disparo de e-mail
  params.append('enviarEmail', 'true');
  params.append('dispararEmail', 'true');
  params.append('sendEmail', 'true');
  params.append('notificar', 'true');
  params.append('notificarEmail', 'true');

  // Integração com Google Agenda (Google Calendar)
  params.append('criarEvento', 'true');
  params.append('adicionarAgenda', 'true');
  params.append('googleCalendar', 'true');
  params.append('adicionarGoogleCalendar', 'true');
  params.append('calendarSync', 'true');
  params.append('tituloEvento', `Reposição: ${dados.aluno} (${dados.turma}) - Prof. ${dados.profSub}`);
  params.append(
    'descricaoEvento',
    `Reposição Pedagógica OPERALAB\nAluno: ${dados.aluno}\nTurma: ${dados.turma}\nLição: ${dados.licao}\nModalidade: ${dados.modalidade}\nProfessor Responsável: ${dados.profSub}\nProfessor Titular: ${dados.profOriginal}\nAgendado por: ${dados.staff}`
  );
  
  // Payload JSON completo
  params.append(
    'payload',
    JSON.stringify({
      ...novoItem,
      dataBr,
      dataIso,
      horaInicio: dados.horaRep,
      horaFim,
      emailProfessor: emailProfSub,
      emailProfOriginal,
      emailVerificacao: EMAIL_VERIFICACAO,
      emailCopia: EMAIL_COORDENACAO,
      enviarEmail: true,
      criarEvento: true,
      adicionarGoogleCalendar: true,
      tituloEvento: `Reposição: ${dados.aluno} (${dados.turma}) - Prof. ${dados.profSub}`,
      descricaoEvento: `Reposição Pedagógica OPERALAB\nAluno: ${dados.aluno}\nTurma: ${dados.turma}\nLição: ${dados.licao}\nModalidade: ${dados.modalidade}\nProfessor Responsável: ${dados.profSub}\nProfessor Titular: ${dados.profOriginal}\nAgendado por: ${dados.staff}`
    })
  );

  try {
    // Disparo principal
    await fetch(URL_API_DESEMPENHO, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });

    return true;
  } catch {
    return false;
  }
}

/**
 * Consulta faltas no Safire com cache local e tolerância a cold start
 */
export async function checkSafireFaltas(alunoNome: string, bypassCache: boolean = false): Promise<SafireStudentCheck> {
  const normKey = `safire_${normalizeString(alunoNome)}`;
  
  if (!bypassCache) {
    try {
      const cached = localStorage.getItem(normKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed && typeof parsed === 'object' && !parsed.error) {
          return parsed;
        }
      }
    } catch {
      // ignore
    }
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 35000);
    const res = await fetch(`${SCRIPT_URL_SAFIRE}?nome=${encodeURIComponent(alunoNome)}&_t=${Date.now()}`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      const data = await res.json();
      if (data && typeof data === 'object' && !data.error) {
        try {
          localStorage.setItem(normKey, JSON.stringify(data));
        } catch {
          // ignore
        }
        return data;
      }
    }
  } catch (err) {
    console.warn(`Erro ao consultar Safire para ${alunoNome}:`, err);
    // Tenta fallback do cache mesmo expirado
    try {
      const cached = localStorage.getItem(normKey);
      if (cached) {
        return JSON.parse(cached);
      }
    } catch {
      // ignore
    }
  }
  return { error: true };
}
